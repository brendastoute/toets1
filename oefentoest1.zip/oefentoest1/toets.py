print ("welkom bij de auditie")
geelen = 4
mevrouwwit= 20

var1= 0
var2= 0 

while True:
    # vragen hieronder:
    aanmelden = input("wilt u aanmelden voor een rol?\nja,nee\n")
    if aanmelden == "ja":
        zin = input("heeft u er zin in?\nja,nee\n")
        leeftijd = int(input("hoe oud is u?\n"))
        diploma = input("heeft u een diploma\nja,nee\n")
        gender = input("bent u een man of een vrouw?\n")
        verlegen = input("bent u verlegen?\nja,nee\n") 
        boos = input("word u snel boos?\nja,nee\n")
    # antwoorden hieronder:
        if zin == "ja":
            print("TOP")
        elif zin == "nee":
            print("sorry u hebt geen rol")
            break

        if leeftijd >= 18:
            var1 = var1 + 1

        elif leeftijd <=18:
            var2 = var2 + 4      

        if diploma == "ja":
            var1 = var1 + 0

        if diploma == "nee": 
            var2 = var2 + 2
            

        if gender == "man":
            var2 = var2 + 3
            var1 = var1 + 0

        if gender == "vrouw":
            var1 = var1 + 2

        if verlegen == "ja":
            var2 = var2 + 7

        elif verlegen == "nee":
            var1 = var1 + 0

        if boos =="ja":
            var2 = var2 + 4
        elif boos == "nee":
            var1 = var1 + 1


        if geelen > var1: 
            print ("u hebt te rol van geelen")

        elif mevrouwwit > var2:
            print("u hebt de rol van mevrouw de wit")
        break
    


    elif aanmelden == "nee":
        print("uhm ok?")






